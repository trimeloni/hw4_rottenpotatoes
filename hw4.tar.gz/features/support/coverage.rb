require 'simplecov'
SimpleCov.start 'rails'
